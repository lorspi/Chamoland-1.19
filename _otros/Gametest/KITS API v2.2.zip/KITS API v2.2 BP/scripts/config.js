/**
 *                        ----- .-CONFIG-. -----
 * Welcome to the configuration file, here you can modify several of the KITS API things!
 * It is recommended to know a minimum amount of javascript, the main thing to understand
 * is that if you do something wrong you can break the whole code!
 */

export default {
    /**
     * This will be the scoreboard that will be used for the economy of the kits
     * It must be a string, that is, it must be enclosed in quotes or single quotes ( "text" or 'text' )
     */
    economyScore: 'money',
    /**
     * This is the main form that comes up when typing the "kit" command and each of its buttons
     */
    MainForm: {
        /**
         * Here you can modify the text and the image that appears in each of the buttons of the main form

         * text: The text that will appear on the button;
         * It must be a string, that is, it must be enclosed in quotes or single quotes ( "text" or 'text' )
         
         * iconPath: The image that will appear on the button;
         * The image you want to place must be in a resource pack and you must copy the exact path of this 
         * (it is recommended to read about resource packs beforehand)
         * It must be a string, that is, it must be enclosed in quotes or single quotes ( "text" or 'text' )
         */
        CreateKit: {
            text: 'Create kit',
            iconPath: 'textures/emojis/CREATE KIT.png'
        },
        removeKit: {
            text: 'Remove kit',
            iconPath: 'textures/emojis/REMOVE KIT.png'
        },
        viewKit: {
            text: 'View kit',
            iconPath: 'textures/emojis/VIEW INFO.png'
        },
        reclaimKit: {
            text: 'Reclaim kit',
            iconPath: 'textures/emojis/RECLAIM.png'
        }
    }
}