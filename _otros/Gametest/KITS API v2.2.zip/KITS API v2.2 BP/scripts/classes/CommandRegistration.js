import { world } from 'mojang-minecraft'
import Collection from './include/Collection.js';
import { Player } from '../utils/Player.js'
import event from './manager/EventEmitter.js'
import CommandError from './error/command.js';
import Interaction from './interaction/interaction.js';
import CommandParser from './parser/command.js'
import { Database } from '../manager/database.js'
import MS from '../utils/ms.js'
import { setTickTimeout } from '../utils/scheduling.js';

class CustomCommand {
    constructor() {
        this.prefix = ".";
        this.commands = new Collection();
        world.events.beforeChat.subscribe(beforeChatPacket => {
            this.exec(beforeChatPacket)
        })
    };
    
    getCommand(command) {
        const cmd = command?.toLowerCase();
        return this.commands.get(cmd) || this.commands.find(v => v.aliases?.includes(cmd));
    };
    
    getAllCommands() {
        return this.commands
    }
    
    getPrefix() {
        return this.prefix
    }
    
    setPrefix(value) {
        this.prefix = value
    }
    
    register(registration, callback) {
        this.commands.set(registration.name.toLowerCase(), {
            ...registration,
            callback
        });
    };
    
    triggerCommand(command, interaction) {
        this.getCommand(command).callBack(interaction)
    }
    
    
    exec(beforeChatPacket) {
        try {
        let { message, sender } = beforeChatPacket
        const Plr = new Player(sender)
        if (!message.startsWith(this.prefix))
            return;
        
        beforeChatPacket.cancel = true
        const args = message.slice(this.prefix.length).trim().match(/([^\s"]+|"[^"]*")+/g)?.map(v => /\s/.test(v) ? v.replace(/^"|"$/g, '') : v);
        
        const commandName = args?.shift()?.toLowerCase();
        const command = this.getCommand(commandName);
        if (!command || command.private && !Plr.hasTag('private'))
            return new CommandError({ message: `${commandName} is an invalid command! Use the help command to get a list of all the commands.`, player: `"${Plr.getName()}"`, });
        if(command.requiredTags.length && !Plr.hasAllTags(command.requiredTags))
            return new CommandError({ message: `you do not have the required permissions to use ${commandName}! you must have all of these tags to execute the command: ${command.requiredTags}`, player: `"${Plr.getName()}"`, })
        
        beforeChatPacket.cancel = command.cancelMessage
        
        let ParsedCommand;
        try {
            ParsedCommand = new CommandParser({ command, args }).toParsedCommand()
        }  catch(e) {
            new CommandError({ message: e.message, player: `"${Plr.getName()}"` })
            return;
        }
            
        const interaction = new Interaction(ParsedCommand, sender, message, args)
        event.emit('commandRan', interaction)
        
        command.callback(interaction);
        } catch(e) {
            console.warn(`say ${e} ${e.stack}, \nplease report error!`)
        }
    };
};

const CommandHandler = new CustomCommand()
export default CommandHandler 
