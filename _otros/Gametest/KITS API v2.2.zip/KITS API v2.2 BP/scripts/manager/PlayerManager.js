import { Player } from '../utils/Player.js'
import { Client } from './Client.js'

export class PlayerManager {
  constructor() {
    this._players = new Map()
  }
  
  add(player) {
    this._players.set(player.getName(), player)
  }
  
  create(player) {
    return new Player(player)
  }
  
  remove(player) {
    this._players.delete(player.getName())
  }
  
  removeByName(playerName) {
    this._players.delete(playerName)
  }
  
  getAll() {
    return this._players
  }
  
  getAllAsArray() {
    return Array.from(this.getAll().values())
  }
  
  getAllNamesAsArray () {
      return Array.from(this.getAll().keys())
  }
  
  getByName(playerName) {
    return this._players.get(playerName)
  }
  
  getByNameTag(nametag) {
    return Array.from(this._players.values()).find((p) => p.getNameTag() === nametag)
  }
  
  getByIPlayer(IPlayer) {
    return Array.from(this._players.value()).find((p) => p.getIPlayer() === IPlayer)
  }
}