import { world as World, Location, BlockLocation, MinecraftBlockTypes } from 'mojang-minecraft'
import { EventEmitter } from './EventEmitter.js'
import Server from '../utils/Server.js'
import { Player } from '../utils/Player.js'
import { Entity } from '../utils/Entity.js'
import { Item } from '../utils/Item.js'
import { Block } from '../utils/Block/Block.js'
import { PlayerManager } from './PlayerManager.js'
import { Database } from './database.js'

class ClientBuilder extends EventEmitter {
  constructor() {
    super();
    this.server = Server
    this.players = new PlayerManager(this)
    this._eventManager();
    this.playerDB = new Database('plrs')
    this.kits = new Database('kits')
    this.bans = new Database('bans')
    this.mutes = new Database('mutes')
    this.reports = new Database('reports')
  }
  
  _eventManager() {
      /**
       * Emit to 'beforeChat' event listener
       */
    World.events.beforeChat.subscribe(data => this.emit('Chat', {
        sender: data.sender,
        message: data.message,
        cancel() {
            data.cancel = true
        }
    }))
    
      /**
       * Emit to 'beforeExplosion' event listener
       */
    World.events.beforeExplosion.subscribe(data => this.emit('beforeExplosion', data))

    let worldLoaded = false, tickCount = 0;
    World.events.tick.subscribe(data => {
    /**
     * Emit to 'Tick' event listener
     */
     this.emit('Tick', data)
     
     tickCount++
     
     if (!this.server.runCommand('testfor @a').error && !worldLoaded) {
       /**
        * Emit to 'ready' event listener
        */
        this.emit('Ready', { loadTime: tickCount })
        worldLoaded = true;
       }
    })
    
    /**
     * Emit to 'entityCreate' event listener
    */
    World.events.entityCreate.subscribe(data => this.emit('EntityCreate', {
       entity: new Entity(data.entity),
       cancel () {
        new Entity(data.entity).despawn()
       }
    }))
    
    /**
     * Emit to 'ItemUse' event listener
    */
    World.events.beforeItemUse.subscribe(data => this.emit('ItemUse', {
        item: new Item(data.item),
        source: new Player(data.source)
    }))

    /**
     * Emit to 'BlockDestroyed' event listener
     */
    World.events.blockBreak.subscribe(data => {
        this.emit('BlockDestroyed', {
            player: data.player,
            block: new Block(data.block),
            brokenBlock: data.brokenBlockPermutation,
            dimension: data.dimension,
            cancel() {
             data.block.setPermutation(data.brokenBlockPermutation)
            }
        })
    })
    
    /**
     * Emit to 'BlockCreated' event listener
    */
    World.events.blockPlace.subscribe(data => {
        this.emit('BlockCreated', {
           player: new Player(data.player),
           block: new Block(data.block),
           dimension: data.dimension,
           cancel() {
                data.dimension.getBlock(new BlockLocation(data.block.location.x, data.block.location.y, data.block.location.z)).setType(MinecraftBlockTypes.air)
            }
        })
    })
    
    /**
     * Emit to 'entityHit' event listener
    */
    World.events.entityHit.subscribe(data => this.emit('EntityHit', {
        attacker: data.entity.id === "minecraft:player" ? new Player(data.entity) : new Entity(data.entity),
        hitBlock: new Block(data.hitBlock),
        hitEntity: !data.hitEntity ? undefined : data.hitEntity.id === "minecraft:player" ? new Player(data.hitEntity) : new Entity(data.hitEntity)
    }))
    
    /**
     * Emit to 'HitPlayer' event listener
     * This event will occur when a player receives a hit
    */
    World.events.entityHit.subscribe(data => {
      if (!data.hitBlock && data.hitEntity.id == 'minecraft:player') this.emit('HitPlayer', {
          attacker: data.entity.id === "minecraft:player" ? new Player(data.entity) : new Entity(data.entity),
          hitPlayer: new Player(data.hitEntity)
      })
    })
    
    /**
     * Emit to 'PlayerHit' event listener
     * This event will occur when a player hits an entity or player
    */
    World.events.entityHit.subscribe(data => {
      if (!data.hitBlock && data.entity.id == 'minecraft:player') this.emit('PlayerHit', {
          attacker: new Player(data.entity),
          hitEntity: data.hitEntity.id === "minecraft:player" ? new Player(data.hitEntity) : new Entity(data.hitEntity)
      })
    })
    
    /**
     * Emit to 'HitPlayerByItem' event listener
     * This event occurs when a player is hit by another player, but in this event you can get the item with which the attacker hit the player
    */
    World.events.entityHit.subscribe(data => {
      if (!data.hitBlock && data.hitEntity.id == "minecraft:player" && data.entity.id == "minecraft:player") {
      let player = new Player(data.entity)
      let inventory = player.getInventory().container
      let slot = player.getSelectedSlot()
      let item = inventory.getItem(slot)
      this.emit('HitPlayerByItem', {
         attacker: new Player(data.entity),
         hitPlayer: data.hitEntity.id === "minecraft:player" ? new Player(data.hitEntity) : new Entity(data.hitEntity),
         item: !item ? undefined : new Item(item)
       })
      }
    })
    
    /**
     * Emit to 'BlockHit' event listener
    */
    World.events.entityHit.subscribe(data => {
      if (!data.hitEntity && data.entity.id === "minecraft:player") this.emit('BlockHit', {
         player: new Player(data.entity),
         hitBlock: new Block(data.hitBlock)
      })
    })
    
    /**
     * Emit to 'entityHurt' event listener
    */
    World.events.entityHurt.subscribe(data => this.emit('EntityHurt', {
        attacker: !data.damagingEntity ? undefined : data.damagingEntity.id === "minecraft:player" ? new Player(data.damagingEntity) : new Entity(data.damagingEntity),
        hurtEntity: data.hurtEntity.id === "minecraft:player" ? new Player(data.hurtEntity) : new Entity(data.hurtEntity),
        cause: data.cause,
        damage: data.damage,
        projectile: new Entity(data.projectile),
        cancel() {
            data.hurtEntity.getComponent("health").setCurrent(data.damage)
        }
    }))
    
    /**
     * Emit to 'projectileHit' event listener
    */
    //World.events.projectileHit.subscribe(data => this.emit('ProjectileHit', data))
    
    /**
     * Emit to 'weatherChange' event listener
    */
    //World.events.weatherChange.subscribe(data => this.emit('WatherChange', data))
    
    /**
     * Emit to 'playerJoin' event listener
    */
    World.events.playerJoin.subscribe(data => {
        const player = this.players.create(data.player)
        this.players.add(player)
        this.emit('PlayerJoin', { joinedPlayer: player })
    })
    
    /**
     * Emit to 'playerLeave' event listener
    */
    World.events.playerLeave.subscribe(data => {
        const player = this.players.getByName(data.playerName)
        
        if (!player) return;
        
        this.emit('PlayerLeave', { player: player })
        
        this.players.remove(player)
    })

    const tickEventCallback = World.events.tick
    let joinedPlayer;
      function onJoinTime () {
        try {
          joinedPlayer.runCommand(`testfor @a[name="${joinedPlayer.name}"]`)
          
          /**
           * Emit to 'PlayerJoinInit' event listener
          */
          this.emit('PlayerJoinInit', { player: new Player(joinedPlayer) })
        } catch (error) {}
      }
      
      World.events.playerJoin.subscribe(data => {
        joinedPlayer = data.player
          
        tickEventCallback.subscribe(onJoinTime)
    })
    
    /**
     * Emit to 'itemStartCharge' event listener
    */
    //World.events.itemStartCharge.subscribe(data => this.emit('ItemStartCharge', data))
    
    /**
     * Emit to 'itemStartUseOn' event listener
    */
    //World.events.itemStartUseOn.subscribe(data => this.emit('ItemStartUseOn', data))
    
    /**
     * Emit to 'itemStopCharge' event listener
    */
    //World.events.itemStopCharge.subscribe(data => this.emit('ItemStopCharge', data))
    
    /**
     * Emit to 'itemStopUseon' event listener
    */
    //World.events.itemStopUseOn.subscribe(data => this.emit('ItemStopUseOn', data))
    
    /**
     * Emit to 'leverActivate' event listener
    */
    World.events.leverActivate.subscribe(data => this.emit('LeverActivate', data))
    
    /**
     * Emit to 'ItemInteract' event listener
    */
    World.events.beforeItemUseOn.subscribe(data => {
    this.emit('ItemInteract', {
    source: new Player(data.source),
    item: !data.item ? undefined : new Item(data.item),
    block: new Block(new Player(data.source).getIPlayer().dimension.getBlock(data.blockLocation)),
    blockLocation: data.blockLocation,
    faceLocationX: data.faceLocationX,
    faceLocationY: data.faceLocationY,
    cancel() {
      data.cancel = true
       }
     })
   })
  }
}

export const Client = new ClientBuilder()