export class ModalFormResponse {
	constructor({ form, components, MojangResponse, player }) {
		this.MojangResponse = MojangResponse
		this.components = components
		this.player = player
		this.form = form
	}
	
	getExited() {
	  return this.MojangResponse.isCanceled
	}
	
	getDropdown(id) {
	  return this.MojangResponse.formValues[this.components.find(component => component.id == id && component.componentType == 'dropdown').responseIndex]
	}
	
	getSlider(id) {
	  return this.MojangResponse.formValues[this.components.find(component => component.id == id && component.componentType == 'slider').responseIndex]
	}
	
	getTogle(id) {
	  return this.MojangResponse.formValues[this.components.find(component => component.id == id && component.componentType == 'togle').responseIndex]
	}
	
	getTextField(id) {
	  return this.MojangResponse.formValues[this.components.find(component => component.id == id && component.componentType == 'textField').responseIndex]
	}
}