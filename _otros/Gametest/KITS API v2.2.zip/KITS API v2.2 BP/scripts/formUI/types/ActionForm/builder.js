import { world } from 'mojang-minecraft'
import { ActionFormResponse } from './response.js'
import { ActionFormData as MActionFormData } from 'mojang-minecraft-ui'
import { EventEmitter } from '../../../classes/manager/EventEmitter.js'

export class ActionFormData extends EventEmitter {
	constructor() {
		super()
		this.MActionFormData = new MActionFormData()
		this.currentResponseIndex = 0
		this.components = []
	}

	setTitle(titleText) {
		this.title = titleText
		this.MActionFormData.title(titleText)
		return this
	}

    setBody(bodyText) {
		this.body = bodyText
		this.MActionFormData.body(bodyText)
		return this
	}

	addButton({ text, iconPath, id }) {
		if (this.components.some(component => component.componentType == 'button' && component.id == id))
			throw new Error(`a button with id: ${id} already exists`)

		this.MActionFormData.button(text, iconPath)
		this.components.push({
			text,
			iconPath,
			id,
			responseIndex: this.currentResponseIndex,
			componentType: 'button'
		})
        this.currentResponseIndex++
		return this
	}

	show(user, callback) {
		const player = typeof user == 'string' ? [...world.getPlayers()].find(player => player.nameTag == user || player.name == user) : user
		this.MActionFormData.show(player).then(MojangResponse => {
			const ActionResponse = new ActionFormResponse({
				form: this.MActionFormData,
				components: this.components,
				MojangResponse,
                player,
			})
			this.emit("playerResponse", ActionResponse)
            
            if(!callback) return
			callback(ActionResponse)
		})
		return this
	}

	setNoCancel() {
		this.on("playerResponse", (playerResponse) => {
			if (!playerResponse.getExited()) return
			this.show(playerResponse.player.nameTag)
		})
		return this
	}
}