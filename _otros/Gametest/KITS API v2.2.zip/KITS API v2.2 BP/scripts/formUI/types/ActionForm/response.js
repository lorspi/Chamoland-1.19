export class ActionFormResponse {
	constructor({ form, components, MojangResponse, player }) {
		this.MojangResponse = MojangResponse
		this.components = components
		this.player = player
		this.form = form
	}
	
	getExited() {
	  return this.MojangResponse.isCanceled
	}
	
	getPressedButton() {
	  return this.components.find(component => component.componentType == 'button' && component.responseIndex == this.MojangResponse.selection).id
	}
}