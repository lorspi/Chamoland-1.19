/*
Developers:
Aex66: 
Discord: Aex66#0202
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
           _____                 
          /  _  \   ____ ___  ___
         /  /_\  \_/ __ \\  \/  /
        /    |    \  ___/ >    < 
        \____|__  /\___  >__/\_ \
                \/     \/      \/
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
© Copyright 2022 all rights reserved. Do NOT steal, copy the code, or claim it as yours.

Thank you
*/

import { ActionFormData } from '../types/ActionForm/builder.js'
import { KitReclaimSelect } from './KitReclaimSelect.js'
import config from '../../config.js'

export function KitFormMember(player, statusMessage = '') {
    const form = new ActionFormData()
    .setTitle('KITS API')
    .setBody(`${statusMessage}§f\n`)
    .addButton({
        text: config.MainForm.reclaimKit.text,
        iconPath: config.MainForm.reclaimKit.iconPath,
        id: 'reclaimKit'
    })
    
    form.show(player, (response) => {
      const pressedButton = response.getPressedButton()
      switch(pressedButton) {
        case 'reclaimKit':
          KitReclaimSelect(response.player)
        break;  
      }
    })
}
