/*
Developers:
Aex66: 
Discord: Aex66#0202
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
           _____                 
          /  _  \   ____ ___  ___
         /  /_\  \_/ __ \\  \/  /
        /    |    \  ___/ >    < 
        \____|__  /\___  >__/\_ \
                \/     \/      \/
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
© Copyright 2022 all rights reserved. Do NOT steal, copy the code, or claim it as yours.

Thank you
*/

import { ActionFormData } from '../types/ActionForm/builder.js'
import { KitForm } from './KitForm.js'
import { KitFormMember } from './KitFormMember.js'
import { Player } from '../../utils/Player.js'
import { newItem } from '../../utils/Item.js'
import { Client } from '../../manager/Client.js'
import { KitInfoSelect } from "./KitInfoSelect.js"
import { Lang } from '../../utils/Lang.js'
import MS from '../../utils/ms.js'

export function KitInfo(player, key, statusMessage = Lang.viewConfirmDefaultStatusMsg.replace('%1', `§r`)) {

  let data = Client.kits.get(key),  
  desc = data.description,
  onlyOnce = data.onlyOnce,
  reqTag = data.requiredTag,
  cooldown = data.cooldown,
  itemCount = data.itemCount

  const form = new ActionFormData()
  .setTitle(`View Kit ${key}`)
  .setBody(statusMessage == Lang.viewConfirmDefaultStatusMsg.replace('%1', `§r`) ? `${Lang.viewConfirmDefaultStatusMsg.replace('%1', key).replace('%2', desc).replace('%3', reqTag).replace('%4', onlyOnce).replace('%5', MS(cooldown)).replace('%6', itemCount)}` : `${statusMessage}\n\n${Lang.viewConfirmDefaultStatusMsg.replace('%1', key).replace('%2', desc).replace('%3', reqTag).replace('%4', onlyOnce).replace('%5', cooldown).replace('%6', itemCount)}`)
  .addButton({
    text: '§cExit',
    iconPath: "textures/emojis/EXIT.png",
    id: 'exit'
  })
  
  form.show(player, (response) => {
    if (response.getExited()) {
        if (response.player.hasTag("staff")) return KitForm(response.player)
        else return KitFormMember(response.player)
    }
  })
}
