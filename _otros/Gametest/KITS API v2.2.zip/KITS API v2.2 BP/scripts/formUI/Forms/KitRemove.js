/*
Developers:
Aex66: 
Discord: Aex66#0202
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
           _____                 
          /  _  \   ____ ___  ___
         /  /_\  \_/ __ \\  \/  /
        /    |    \  ___/ >    < 
        \____|__  /\___  >__/\_ \
                \/     \/      \/
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
© Copyright 2022 all rights reserved. Do NOT steal, copy the code, or claim it as yours.

Thank you
*/

import { ModalFormData } from '../types/ModalForm/builder.js'
import { KitForm } from './KitForm.js'
import { Player } from '../../utils/Player.js'
import { Lang } from '../../utils/Lang.js'
import { Client } from '../../manager/Client.js'

export function KitRemove(player, statusMessage = Lang.removeDefaultStatusMsg) {

    const kits = Client.kits.allKeys()
  let vKits = []
  for (let key of kits) {
    vKits.push(key)
  }
  if (!vKits.length || vKits.length === 0) vKits = ['none']
  
  const form = new ModalFormData()
  .setTitle('Remove Kit')
  .addDropdown({
    label: 'Select the kit you want to remove',
    options: vKits,
    defaultValueIndex: 0,
    id: 'kitss'
  })
   .addTextField({
    label: statusMessage == Lang.removeDefaultStatusMsg ? Lang.removeDefaultStatusMsg : `${statusMessage}\n\n${Lang.removeDefaultStatusMsg}`,
    placeholderText: 'CONFIRM OR CANCEL',
    defaultValue: '',
    id: 'confirm'
  })
 
  form.show(player, (response) => {
    if (response.getExited()) return KitForm(response.player)

    const Plr = new Player(response.player)
    if (vKits[0] === 'none') return KitForm(response.player, Lang.noKitsFound)
    
    const confirmation = response.getTextField('confirm')
    const selectionn = response.getDropdown('kitss')
    
    if (!confirmation) return KitRemove(response.player)
   if (confirmation != 'CONFIRM') return KitRemove(response.player)
   let kitR = Client.kits.get(vKits[selectionn]).name
   Client.emit('kitRemoved', {
    kit: kitR,
    player: response.player
   })
    Client.kits.delete(kitR)
    KitForm(response.player, Lang.removeSucces.replace('%1', kitR))
  })
}