/*
Developers:
Aex66: 
Discord: Aex66#0202
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
           _____                 
          /  _  \   ____ ___  ___
         /  /_\  \_/ __ \\  \/  /
        /    |    \  ___/ >    < 
        \____|__  /\___  >__/\_ \
                \/     \/      \/
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
© Copyright 2022 all rights reserved. Do NOT steal, copy the code, or claim it as yours.

Thank you
*/

import { ActionFormData } from '../types/ActionForm/builder.js'
import { KitReclaimSelect } from './KitReclaimSelect.js'
import { KitFormMember } from './KitFormMember.js'
import { Player } from '../../utils/Player.js'
import { newItem } from '../../utils/Item.js'

import { Client } from '../../manager/Client.js'
import { Lang } from '../../utils/Lang.js'
import { toDuration } from '../../utils/ms.js'

export function KitReclaimMember(player, key, statusMessage = Lang.reclaimDefaultStatusMsg.replace('%1', '§r')) {

  let data = Client.kits.get(key)
  let desc = data.description

  const form = new ActionFormData()
  .setTitle(`${key}`)
  .setBody(statusMessage === `${Lang.reclaimDefaultStatusMsg.replace('%1', '§r')}` ? `${Lang.reclaimDefaultStatusMsg.replace('%1', desc)}\n§7Cooldown: §e${toDuration(data.cooldown)}` : `${statusMessage}\n\n${Lang.reclaimDefaultStatusMsg.replace('%1', desc)}\n§7Cooldown: §e${toDuration(data.cooldown)}`)
  .addButton({
    text: 'Confirm',
    iconPath: "textures/emojis/CHECK.png",
    id: 'confirm'
  })
  .addButton({
    text: 'Return',
    iconPath: "textures/emojis/RETURN.png",
    id: 'return'
  })
  
  form.show(player, (response) => {
    if (response.getExited()) return KitFormMember(response.player)
    
    const Plr = new Player(response.player)
    const pressedButton = response.getPressedButton()
    
    switch(pressedButton) {
      case 'confirm':
          
        let items = Client.kits.get(key).items
      
    const inv = Plr.getInventory().container
    if (data.requiredTag && data.requiredTag !== 'noReqTag' && !Plr.hasTag(data.requiredTag)) return KitReclaimSelect(response.player, Lang.noPerms + "§r")
    const cooldown = Plr.getTags().find((tag) => tag.startsWith(`kitCooldown:${data.name}:`))?.substring(12 + data.name.length + 1) ?? null;
    
    if (cooldown && cooldown > Date.now()) 
        return (
        (KitReclaimSelect(response.player, Lang.inCooldown.replace("%1", toDuration(cooldown - Date.now()))))
      )
      Plr.removeTag(`kitCooldown:${data.name}:${cooldown}`);
      Plr.addTag(`kitCooldown:${data.name}:${Date.now() + data.cooldown}`)
      
    if (data.onlyOnce && Plr.hasTag(`ClaimedKit:${data.name}`)) return KitReclaimSelect(response.player, Lang.onlyOnce)
    
    if (data.onlyOnce) Plr.addTag(`ClaimedKit:${data.name}`)

    let emptys = inv.emptySlotsCount
    if (emptys < data.itemCount) 
        return KitReclaimSelect(response.player, Lang.insufficientSlotsCount.replace('%1', data.itemCount))
    const money = Plr.getScore('money')
    if (data?.price && data?.price > 0 && money < data?.price)
        return KitReclaimSelect(response.player, Lang.insufficientMoney)
    if (data?.price && data?.price > 0 && money >= data?.price) {
      Plr.removeScore('money', data.price)
    }        
    
        for (let item of items) {
            let iitem = newItem(item)
            inv.addItem(iitem)
        }
      Client.emit('kitClaimed', {
        kit: key,
        player: response.player
      })
      if (data?.price <= 0)
          return KitFormMember(response.player, Lang.reclaimSucces.replace('%1', key))
      else if (data?.price > 0)
          return KitFormMember(response.player, Lang.purchasedKitSucces.replace('%1', key))     
      break;
      case 'return':
        KitReclaimSelect(response.player)
     }
  })
}