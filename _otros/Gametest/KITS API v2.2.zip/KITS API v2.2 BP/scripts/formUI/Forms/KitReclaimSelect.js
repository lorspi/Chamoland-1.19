/*
Developers:
Aex66: 
Discord: Aex66#0202
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
           _____                 
          /  _  \   ____ ___  ___
         /  /_\  \_/ __ \\  \/  /
        /    |    \  ___/ >    < 
        \____|__  /\___  >__/\_ \
                \/     \/      \/
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
© Copyright 2022 all rights reserved. Do NOT steal, copy the code, or claim it as yours.

Thank you
*/

import { ModalFormData } from '../types/ModalForm/builder.js'
import { KitReclaimStaff } from './KitReclaimStaff.js'
import { KitReclaimMember } from './KitReclaimMember.js'
import { KitForm } from './KitForm.js'
import { KitFormMember } from './KitFormMember.js'
import { Player } from '../../utils/Player.js'
import { Client } from '../../manager/Client.js'
import { Lang } from '../../utils/Lang.js'

export function KitReclaimSelect(player, statusMessage = Lang.reclaimSelectDefaultStatusMsg) {
    
  const kits = Client.kits.allKeys()
  let vKits = [];
  for (let key of kits) {
    vKits.push(key)
  }
  
  if (!vKits || vKits.length == 0) vKits = ['none']
  
  const form = new ModalFormData()
  .setTitle('Reclaim kit')
  .addDropdown({
    label: statusMessage === Lang.reclaimSelectDefaultStatusMsg ? Lang.reclaimSelectDefaultStatusMsg : `${statusMessage}\n\n${Lang.reclaimSelectDefaultStatusMsg}`,
    options: vKits,
    defaultValueIndex: 0,
    id: 'kits'
  })
  
  form.show(player, (response) => {
    if (response.getExited()) {
        if (response.player.hasTag("staff"))
        return KitForm(response.player)
        else return KitFormMember(response.player)
    }
    
    const Plr = new Player(response.player)
    
    if (vKits[0] === 'none') return KitForm(response.player, Lang.noKitsFound)
    const selection = response.getDropdown('kits')
    console.warn(`§1[Console]§3[Log]: §r${vKits[selection]}`)
    switch(!!Plr.hasTag("staff")) {
        case true:
            KitReclaimStaff(response.player, vKits[selection])
        break;
        case false:
            KitReclaimMember(response.player, vKits[selection])
        break;   
    }
  })
}
