/*
Developers:
Aex66: 
Discord: Aex66#0202
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
           _____                 
          /  _  \   ____ ___  ___
         /  /_\  \_/ __ \\  \/  /
        /    |    \  ___/ >    < 
        \____|__  /\___  >__/\_ \
                \/     \/      \/
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
© Copyright 2022 all rights reserved. Do NOT steal, copy the code, or claim it as yours.

Thank you
*/

import { ModalFormData } from '../types/ModalForm/builder.js'
import { KitForm } from './KitForm.js'
import { Player } from '../../utils/Player.js'
import { MS } from '../../utils/ms.js'
import { getItemData } from '../../utils/Item.js'
import { Client } from '../../manager/Client.js'
import { Lang } from '../../utils/Lang.js'

export function KitCreate(player, statusMessage = Lang.createDefaultStatusMsg) {

  const form = new ModalFormData() 
  .setTitle('Create kit')
  .addTextField({
    label: statusMessage == Lang.createDefaultStatusMsg ?  `${Lang.createDefaultStatusMsg}` : `${statusMessage}\n\n${Lang.createDefaultStatusMsg}`,
    placeholderText: 'Add the name of kit',
    defaultValue: '',
    id: 'kitName'
  })
  .addTextField({
      label: 'Description',
      placeholderText: 'Add the desc of kit',
      defaultValue: 'Def',
      id: 'kitDesc'
      
  })
  .addTextField({
    label: 'Required tag',
    placeholderText: 'Tag',
    id: 'kitTag'
  })
  .addTextField({
    label: 'Cooldown',
    placeholderText: 'Cooldown', 
    id: 'kitCooldown'
  })
  .addTextField({
    label: 'Price\n(\'0\' is free kit)',
    placeholderText: 'KIT PRICE',
    defaultValue: '0',
    id: 'price'
  })
  .addTogle({
    label: 'Can only be claimed once',
    defaultValue: false,
    id: 'onlyOnce'
  })
  
  form.show(player, (response) => {
    if (response.getExited()) return KitForm(response.player)
    const Plr = new Player(response.player)
    
    const kitName = response.getTextField("kitName")
    let kitDesc = response.getTextField("kitDesc")
    const kitTag = response.getTextField("kitTag")
    const kitDate = response.getTextField("kitCooldown"),
    kitCooldown = MS(kitDate),
    price = Number(response.getTextField('price'))
    const onlyOnce = response.getTogle("onlyOnce")
    if (!kitDesc) kitDesc = 'Null'
    if (!kitName) 
        return KitCreate(response.player, Lang.createNoName)
    if (!price || isNaN(price))
        return KitCreate(response.player, Lang.createPriceErr1)
    if (Client.kits.has(kitName)) 
        return KitCreate(response.player,`${Lang.createArExistKit.replace('%1', kitName)}`)

    const inv = Plr.getInventory().container
    let items = [],
    itemCount = 0
    for (let i=0; i < inv.size; i++) {
      const item = inv.getItem(i)
      if (!item) { continue; }
      
      let itemData = getItemData(item)
     itemCount++
     items.push(itemData)
    }
    
    if (!items.length) return KitCreate(response.player, `${Lang.createNoItems}`)

    let kitData = {
      name: kitName,
      description: kitDesc,
      requiredTag: !kitTag ? "noReqTag" : kitTag, 
      cooldown: !kitCooldown ? 0 : kitCooldown,
      price,
      onlyOnce: !onlyOnce ? false : onlyOnce,
      itemCount,
      items: items
     }
     Client.emit('kitCreated', {
      kit: kitName,
      player: response.player
    })
     Client.kits.set(kitName, kitData, true)
     KitForm(response.player, `${Lang.createSucces.replace('%1', kitName)}`)
  })
}