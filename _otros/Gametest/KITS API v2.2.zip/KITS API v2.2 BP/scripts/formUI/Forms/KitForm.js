/*
Developers:
Aex66: 
Discord: Aex66#0202
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
           _____                 
          /  _  \   ____ ___  ___
         /  /_\  \_/ __ \\  \/  /
        /    |    \  ___/ >    < 
        \____|__  /\___  >__/\_ \
                \/     \/      \/
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
© Copyright 2022 all rights reserved. Do NOT steal, copy the code, or claim it as yours.

Thank you
*/

import { ActionFormData } from '../types/ActionForm/builder.js'
import { KitCreate } from './KitCreate.js'
import { KitRemove } from './KitRemove.js'
import { KitInfoSelect } from './KitInfoSelect.js'
import { KitReclaimSelect } from './KitReclaimSelect.js'
import config from '../../config.js'
export function KitForm(player, statusMessage = '') {
    const form = new ActionFormData()
    .setTitle('KITS API')
    .setBody(`${statusMessage}§f\n`)
    .addButton({
      text: config.MainForm.CreateKit.text,
      iconPath: config.MainForm.CreateKit.iconPath,
      id: 'createKit'
    })
    . addButton({
      text: config.MainForm.removeKit.text,
      iconPath: config.MainForm.removeKit.iconPath,
      id: 'removeKit'
    })
    .addButton({
     text: config.MainForm.viewKit.text,
     iconPath: config.MainForm.viewKit.iconPath,
     id: 'vieWKit'
    })
    .addButton({
        text: config.MainForm.reclaimKit.text,
        iconPath: config.MainForm.reclaimKit.iconPath,
        id: 'reclaimKit'
    })
    
    form.show(player, (response) => {
      const pressedButton = response.getPressedButton()
      switch(pressedButton) {
        case 'createKit':
          KitCreate(response.player)
        break;
        case 'removeKit':
          KitRemove(response.player)
        break;
        case 'vieWKit':
          KitInfoSelect(response.player)
        break;
        case 'reclaimKit':
          KitReclaimSelect(response.player)
        break;  
      }
    })
}
