/*
Developers:
Aex66: 
Discord: Aex66#0202
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
           _____                 
          /  _  \   ____ ___  ___
         /  /_\  \_/ __ \\  \/  /
        /    |    \  ___/ >    < 
        \____|__  /\___  >__/\_ \
                \/     \/      \/
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
© Copyright 2022 all rights reserved. Do NOT steal, copy the code, or claim it as yours.

Thank you
*/

import { ActionFormData } from '../types/ActionForm/builder.js'
import { KitReclaimSelect } from './KitReclaimSelect.js'
import { KitForm } from './KitForm.js'
import { Player } from '../../utils/Player.js'
import { newItem } from '../../utils/Item.js'

import { Client } from '../../manager/Client.js'
import { Lang } from '../../utils/Lang.js'
import { toDuration } from '../../utils/ms.js'

export function KitReclaimStaff(player, key, statusMessage = Lang.reclaimDefaultStatusMsg.replace('%1', '§r')) {

  let data = Client.kits.get(key)
  let desc = data.description

  const form = new ActionFormData()
  .setTitle(`${key}`)
  .setBody(statusMessage === `${Lang.reclaimDefaultStatusMsg.replace('%1', '§r')}` ? `${Lang.reclaimDefaultStatusMsg.replace('%1', desc)}\n§7Cooldown: §e${toDuration(data.cooldown)}` : `${statusMessage}\n\n${Lang.reclaimDefaultStatusMsg.replace('%1', desc)}\n§7Cooldown: §e${toDuration(data.cooldown)}`)
  .addButton({
    text: 'Confirm',
    iconPath: "textures/emojis/CHECK.png",
    id: 'confirm'
  })
  .addButton({
    text: 'Return',
    iconPath: "textures/emojis/RETURN.png",
    id: 'return'
  })
  
  form.show(player, (response) => {
    if (response.getExited()) return KitForm(response.player)
    
    const Plr = new Player(response.player)
    const pressedButton = response.getPressedButton()
    
    switch(pressedButton) {
      case 'confirm':
          
        let items = Client.kits.get(key).items,
        data = Client.kits.get(key)
      
    const inv = Plr.getInventory().container

    let emptys = inv.emptySlotsCount
      if (emptys < data.itemCount) return KitReclaimSelect(response.player, Lang.insufficientSlotsCount.replace('%1', data.itemCount))
      
        for (let item of items) {
            let iitem = newItem(item)
            inv.addItem(iitem)
        }
      Client.emit('kitClaimed', {
          kit: key,
          player: response.player
      })
      KitForm(response.player, Lang.reclaimSucces.replace('%1', key))
      break;
      case 'return':
        KitReclaimSelect(response.player)
     }
  })
}