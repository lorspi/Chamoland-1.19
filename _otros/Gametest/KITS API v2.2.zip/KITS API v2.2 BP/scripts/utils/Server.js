import { world } from "mojang-minecraft"

class ServerBuilder {
    constructor() {
        this.dimension = world.getDimension('overworld')
    }
    
       /**
       * Close your server
       */
    close () {
        function crash() {
            while(true) {
                crash()
            }
        }
        crash()
    }
    
     /**

    * Run a command in game

    * @param command The command you want to run
    * @param dimension The dimension you want the command run
    * @example .runCommand('say Hello World!');
    */
    runCommand(command, dimension) {
        try {
            return { error: false, ...world.getDimension(dimension ?? 'overworld').runCommand(command) };
        }
        catch (error) {
            return { error: true };
        }
    }
    
      /**
   * Run an array of commands
   * @param {Array<string>} commands Put '%' before your commands. It will make it so it only executes if all the commands thta came before it executed successfully!
   * @returns {{ error: boolean }}
   * @example runCommands([
   * 'clear "Smell of curry" diamond 0 0',
   * '%say Smell of curry has a Diamond!'
   * ]);
   */
  runCommands(commands) {
    try {
      const conditionalRegex = /^%/;
      if (conditionalRegex.test(commands[0]))
        throw new Error(
          "[Server]: runCommands(): Error - First command in the Array CANNOT be Conditional"
        );
      let error = false;
      commands.forEach((cmd) => {
        if (error && conditionalRegex.test(cmd)) return;
        error = this.runCommand(cmd.replace(conditionalRegex, "")).error;
      });
    } catch (error) {
      return { error: error };
    }
  }
}

const Server = new ServerBuilder()
export default Server