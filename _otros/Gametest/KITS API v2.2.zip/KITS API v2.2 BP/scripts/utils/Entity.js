import { world as World, Dimension as IDimension, Entity as _IEntity, Effect, EffectType, Vector, Location, EntityQueryOptions } from 'mojang-minecraft'

export class Entity {
  constructor(entity) {
    this._IEntity = entity
    this.dimension = World.getDimension("overworld")
  }
  
  kill() {
    try {
      this._IEntity.kill()
    } catch {}
  }
  
  getIEntity() {
    return this._IEntity
  }
  
  getId() {
    return this._IEntity.id
  }
  
  getNameTag() {
    return this._IEntity.nameTag
  }
  
  setNameTag(nametag) {
    this._IEntity.nameTag = nametag
  }
  
  getTags() {
    return this._IEntity.getTags()
  }
  
  hasTag(tag) {
    return this._IEntity.hasTag(tag)
  }
  
  hasAllTags(tags) {
    return tags.every(tag => this.hasTag(tag))
  }
  
  addTag(tag) {
    return this._IEntity.addTag(tag)
  }
  
  removeTag(tag) {
    return this._IEntity.removeTag(tag)
  }
  
  executeCommand(cmd,debug = false) {
    try {
      const command = this._IEntity.runCommand(cmd)

      return {
        statusMessage: command.statusMessage,
        data: command,
        err: false,
      }
    } catch (error) {
      if (debug) console.warn(`[KITS-API] [Entity#executeCommand]: ${String(error)}`)

      return {
        statusMessage: String(error),
        data: null,
        err: true,
      }
    }
  }
  
  getScore(objective) {
    const data = this.executeCommand(`scoreboard players test @s "${objective}" * *`);
    if (data.error)
    return 0
    return parseInt(String(data.statusMessage?.split(' ')[1]), 10)
  }
  
  setScore(objective, amount) {
    this.executeCommand(`scoreboard players set @s "${objective}" ${amount}`)

    return this.getScore(objective)
  }
  
  addScore(objective, amount) {
    this.executeCommand(`scoreboard players add @s "${objective}" ${amount}`)

    return this.getScore(objective)
  }
  
  removeScore(objective, amount) {
    this.executeCommand(`scoreboard players remove @s "${objective}" ${amount}`)

    return this.getScore(objective)
  }
  
  getPos() {
    const pos = this._IEntity.location

    return {
      x: pos.x,
      y: pos.y,
      z: pos.z,
    }
  }
  
  getDimension() {
    return this._IEntity.dimension
  }
  
  getDimensionName() {
    const id = this.getDimension().id.split(':')[1].replace(/_/g, ' ')

    return id
  }
  
  getInventory() {
    if (!this._IEntity.hasComponent('minecraft:inventory')) return

    return this._IEntity.getComponent('minecraft:inventory')
  }
  
  getHealth() {
    return this._IEntity.getComponent('minecraft:health')
  }
  
  getVelocity() {
    return this._IEntity.velocity
  }
  
  setVelocity(velocity) {
    this._IEntity.setVelocity(velocity)
  }
  
  teleport(location, dimension, xrot, yrot) {
    const loc = new Location(location.x,location.y,location.z)
    
    this._IEntity.teleport(loc, World.getDimension(dimension), xrot, yrot)
  }
  
  triggerEvent(event) {
    this._IEntity.triggerEvent(event)
  }
  
  getRotation() {
    return this._IEntity.bodyRotation
  }
  
  getHeadLocation() {
    const pos = this._IEntity.headLocation
    return {
      x: pos.x,
      y: pos.y,
      z: pos.z
    }
  }
  
  getComponent(component) {
    return this._IEntity.getComponent(component)
  }
  
  hasComponent(component) {
    return this._IEntity.hasComponent(component)
  }
  
  addEffect(effect, duration, amplifier) {
    return this._IEntity.addEffect(effect, duration, amplifier)
  }
  
  getEffect(effect) {
    return this._IEntity.getEffect(effect)
  }
  
  getClosestEntities(maxDistance = null, type = false, closest = 2) {
    let q = new EntityQueryOptions()
    q.location = this.getPos()
    if (closest) q.closest = closest;
    if (type) q.type = type
    if (maxDistance) q.maxDistance = maxDistance;
    let entities  = [...World.getDimension(this.getDimensionName()).getEntities(q)];
    entities.shift()
    return entities
  }
  
  despawn() {
    this._IEntity.teleport(new Location(0,-70, 0), this.getDimension(), 0, 0)
    this.kill()
  }
  
  sendMessage(message) {
      this.executeCommand(`tellraw @s {"rawtext":[{"text":"${message}"}]}`)
  }
}