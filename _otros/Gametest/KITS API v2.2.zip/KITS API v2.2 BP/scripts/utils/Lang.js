/**
               ---LANG---
                English
 Here all the messages that are show when doing something in the addon are controlled, if you want to translate them into your language you are free to do, so but do not forget that the "%1" or anything that begins with "%" and often has a number are parameters, the parameters (or arguments) is for example to call the name of something without having to write it in the same lang, these "%N" when sending the lang are replaced by what is needed at the moment, for example, when a player dies, a message appears in the chat that says "player name" has died.  "playername" is the parameter or argument, so the %N would be replaced with "playername" to finally send the message "playername" is dead.  I hope this is clear and only modify this if you understand and know how to do it.
*/

/**
               ---LANG---
                 Spanish
 Aquí se controlan todos los mensajes que se muestran al hacer algo en el addon, si quieres traducirlos a tu idioma estás en la libertad de hacerlo, pero no olvides que los "%1" o cualquier cosa que empieze por "%" y seguido tenga un número son parámetros, los parámetros (o argumentos) es por ejemplo para llamar al nombre de algo sin necesidad de escribirlo en el mismo lang, estos "%N" al enviar el lang se reemplazan por lo que se necesite en el momento, por ejemplo, cuando un jugador muere sale un mensaje en el chat que dice "nombre del jugador" ha muerto. "nombre del jugador" es el parámetro o argumento, entonces el %N se reemplazaría por "nombre de jugador" para finalmente enviar el mensaje "nombre del jugador" ha muerto. Espero haya quedado claro y solo modifica esto si entendiste y sabes cómo hacerlo.
*/

/**
 * Lang file
 */
export const Lang = {
  createDefaultStatusMsg: '§7When you make a kit, all the items in your inventory will be added to the kit, make sure you add the correct items\n§bNote: §cDont use especial chars §a(colors can be added, this special character is allowed) §cin the name, §cdescription, requiredTag or even the nameTags, lores of the items because the database does not support these chars\n\n§rName',
  createArExistKit: '§cAlready exists a kit with the name: %1',
  createSucces: '§aThe §e%1 §bkit §ahas been created succesfully',
  createNoName: '§cYou must put a name to the kit',
  createNoItems: '§cUps! You cant create a empty kit',
  createPriceErr1: '§cUps! Wrong syntax for the price!',
  removeDefaultStatusMsg: 'Type §a"CONFIRM" §rto §eCONTINUE §ror §c"CANCEL" §rto §eCANCEL',
  removeSucces: '§aThe §e%1 §bkit §ahas been removed succesfully',
  reclaimDefaultStatusMsg: '§f¿§eAre you sure you want to reclaim this kit§f?\n\n§7Kit description:§r %1',
  reclaimSucces: '§eYou have claimed the kit §c%1',
  reclaimSelectDefaultStatusMsg: '§rSelect the kit you want to reclaim',
  viewDefaultStatusMsg: '§rSelect the kit you want to see',
  viewConfirmDefaultStatusMsg: '§bThis is all the information of kit §r§e%1\n\n§r§7Description: §r§b%2\n§7RequiredTag: §r§a%3\n§7OnlyOnce: §r§c%4\n§7Cooldown: §b§d%5\n§7Amount of items: §r§c%6',
  noKitsFound: '§cNo kits found',
  insufficientSlotsCount: '§cYou dont have enough spaces to receive this kit §b(§e%1§b)',
  noPerms: '§cYou dont have permission to reclaim this kit',
  inCooldown: '§cYou have §e%1 §cleft to reclaim this kit again',
  onlyOnce: "§cUps, this kit was set up for a one-time claim and you've already claimed it!",
  insufficientMoney: '§cUps! You don\'t have enough money',
  purchasedKitSucces: '§eYou have purchased the kit §c%1'
}