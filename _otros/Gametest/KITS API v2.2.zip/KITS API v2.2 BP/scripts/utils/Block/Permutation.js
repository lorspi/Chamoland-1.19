import { BlockType } from './BlockType.js'

export class Permutation {

  constructor(IPermutation) {
    this._IPermutation = IPermutation
  }

  getIPermutation() {
    return this._IPermutation
  }

  getType() {
    return new BlockType(this._IPermutation.type)
  }

  getTags() {
    return this._IPermutation.getTags()
  }

  hasTag(tag) {
    return this._IPermutation.hasTag(tag)
  }

  getProperties() {
    return this._IPermutation.getAllProperties()
  }
  
  hasProperty(property) {
    const check = this.getProperties().find((x) => x.name === property)
    if (!check) return false

    return true
  }

  getProperty(property) {
    return this._IPermutation.getProperty(property)
  }

  clone() {
    return new Permutation(this._IPermutation.clone())
  }
}