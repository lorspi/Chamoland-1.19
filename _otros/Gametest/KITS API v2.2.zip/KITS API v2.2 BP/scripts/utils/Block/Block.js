import { BlockType } from './BlockType.js'
import { Permutation } from './Permutation.js'
import { BlockInventory } from '../Inventory/BlockInventory.js'

export class Block {

  constructor(IBlock) {
    this._IBlock = IBlock
  }

  getIBlock() {
    return this._IBlock
  }

  getId() {
    return this._IBlock.id
  }

  getType() {
    return new BlockType(this._IBlock.type)
  }

  setType(type) {
    this._IBlock.setType(type.getIBlockType())
  }

  getPermutation() {
    return new Permutation(this._IBlock.permutation)
  }

  setPermutation(permutation) {
    this._IBlock.setPermutation(permutation.getIPermutation())
  }

  getDimension() {
    return this._IBlock.dimension
  }

  getDimensionName() {
    const id = this.getDimension().id.split(':')[1].replace(/_/g, ' ')

    return id
  }

  getLocation() {
    const pos = this._IBlock.location

    return {
      x: Math.floor(pos.x),
      y: Math.floor(pos.y),
      z: Math.floor(pos.z),
    }
  }

  isEmpty() {
    return this._IBlock.isEmpty
  }

  isWaterLogged() {
    return this._IBlock.isWaterlogged
  }
  
  getTags() {
    return this._IBlock.getTags()
  }

  hasTag(tag) {
    return this._IBlock.hasTag(tag)
  }

  getComponent(component) {
    return this._IBlock.getComponent(component)
  }

  getInventory() {
    if (!this.getComponent('inventory')) return;

    return new BlockInventory(this._IBlock.getComponent('inventory'))
  }
}
