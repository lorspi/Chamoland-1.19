export class BlockType {

  constructor(IBlockType) {
    this._IBlockType = IBlockType
  }

  getIBlockType() {
    return this._IBlockType
  }
  
  getId() {
    return this._IBlockType.id
  }

  canBeWaterLogged() {
    return this._IBlockType.canBeWaterlogged
  }

  createPermutation() {
    return this._IBlockType.createDefaultBlockPermutation()
  }
}