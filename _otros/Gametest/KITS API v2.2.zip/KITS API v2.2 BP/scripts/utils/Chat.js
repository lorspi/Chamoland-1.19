import { world } from 'mojang-minecraft'
import Server from "./Server.js"
class ChatBuilder {
  constructor() {
    this.dimension = world.getDimension("overworld")
    this.runCommands = Server.runCommands;
    this.runCommand = Server.runCommand;
  }
  /**

     * Broadcast a message in chat with possibility to translate these into langs 

     * @param {string} text Message you want to broadcast in chat
     * @param {string} player Player you want to broadcast to
     * @param {string} use What thing is the player using
     * @param {array} args Why do you want to replace the %s in the lang (in order)
     * @example .broadcast('Lang1', 'Noobmaster69', 'Test', ["Noobmaster"])
     * Lang1: Hi! %s
     * Output: Test >> Hi! Noobmaster
     */
  broadcast(text, player, use, args = []) {
    try {
      if (!use) use = ''
      else use = use.toUpperCase() + ' '
      args = args.map(String).filter((n) => n);
      return this.runCommand(
        `execute ${player ? `"${player}"` : '@a'} ~~~ tellraw @s {"rawtext":[{"text":"§➥§l${use} >>"},{"translate":"${text}","with":${JSON.stringify(args)}}]}`
      );
       } catch (error) {
       return { error: true };
     }
   }
   
   /**

     * Broadcast a tip in chat to suggest something the player should do

     * @param {string} text The "tip" you want to broadcast in chat
     * @param {string} player Player you want to a error broadcast to
     * @param {string} use What thing is the player using
     * @param {array} args Why do you want to replace the %s in the lang (in order)
     * @example .tBroadcast('Lang2', 'Noobmaster69', 'Server', ["Noobmaster"]);
     * Lang: %s Dont kill dolphins!
     * Output: Server TIP >> Noobmaster Dont kill dolphins!
     */
    tBroadcast(text, player, use, args = []) {
        if (!use)
            use = '';
        else
            use = use.toUpperCase() + ' ';
            args = args.map(String).filter((n) => n)
        return this.runCommands([
            `execute ${player ? `"${player}"` : '@a'} ~~~ playsound random.toast @s ~~~ 1 0.5`,
            `execute ${player ? `"${player}"` : '@a'} ~~~ tellraw @s {"rawtext":[{"text":"§➥§l§c${use}§aTIP §e>> §r§e "},{"text":${JSON.stringify(text)}}]}`
        ]);
    }
   
   /**

     * Broadcast a ERROR message in chat

     * @param {string} text The error message you want to broadcast in chat
     * @param {string} player Player you want to a error broadcast to
     * @param {string} use What thing is the player using
     * @param {array} args Why do you want to replace the %s in the lang (in order)
     * @example .eBroadcast('Lang3', 'Noobmaster69', 'Task', ["Task1"])
     * Lang: %s failed!
     * Output: Task Error >> Task1 failed!
     */
    eBroadcast(text, player, use, args = []) {
        if (!use)
            use = '';
        else
            use = use.toUpperCase() + ' ';
            args = args.map(String).filter((n) => n)
        return this.runCommands([
            `execute ${player ? `"${player}"` : '@a'} ~~~ playsound random.glass @s ~~~ 1 0.5`,
            `execute ${player ? `"${player}"` : '@a'} ~~~ tellraw @s {"rawtext":[{"text":"§➥§l§c${use}§4Error §c>> §r§c "},{"translate":"${text}","with":${JSON.stringify(args)}}]}`
        ]);
    }
}

const Chat = new ChatBuilder()
export default Chat

