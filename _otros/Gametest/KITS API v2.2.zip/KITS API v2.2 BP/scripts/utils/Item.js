import { world as World, MinecraftEnchantmentTypes, Enchantment, ItemStack as _IItem, ItemStack, Items, MinecraftItemTypes } from 'mojang-minecraft'
import { getEnchants } from './getEnchants.js'

export class Item {
    constructor(item) {
        this._IItem = item
        this.dimension = World.getDimension('overworld')
        }
    getIItem() {
        return this._IItem
    }

    getId() {
        return this._IItem.id
    }

    getAmount() {
        return this._IItem.amount
    }

    getData() {
        return this._IItem.data
    }

    getNameTag() {
        return this._IItem.nameTag
    }

    getLore() {
        return this._IItem.getLore()
    }

    getComponents() {
        return this._IItem.getComponents()
    }

    getComponent(component) {
        return this._IItem.getComponent(component)
    }

    getEnchantments() {
        return getEnchants(this._IItem)
    }

    setNameTag(nametag) {
        this._IItem.nameTag = nametag
    }

    setLore(lore) {
        this._IItem.setLore()
    }

    hasLore() {
        if (this.getLore().find((x) => x === lore)) return true;
        return false;
    }

    hasComponent(component) {
        return this._IItem.hasComponent(component)
    }

    triggerEvent(event) {
        this._IItem.triggerEvent(event)
    }
  
    addEnchantment(enchantment, level) {
        if (!this.hasComponent('minecraft:enchantments')) return false
        const component = this._IItem.getComponent('minecraft:enchantments')
        const enchantments = component.enchantments
        const res = enchantments.addEnchantment(new Enchantment(MinecraftEnchantmentTypes[enchantment], level))
        component.enchantments = enchantments

        return res
      }

    removeEnchantment(enchantment) {
        if (!this.hasComponent('minecraft:enchantments')) return false
        if (!this.hasEnchantment(enchantment)) return false
        const component = this._IItem.getComponent('minecraft:enchantments')
        const enchantments = component.enchantments
        enchantments.removeEnchantment(MinecraftEnchantmentTypes[enchantment])
        component.enchantments = enchantments
    
        return true
      }

    hasEnchantment(enchantment) {
        if (!this.hasComponent('minecraft:enchantments')) return false
        const component = this._IItem.getComponent('minecraft:enchantments')
    
        return component.enchantments.hasEnchantment(MinecraftEnchantmentTypes[enchantment]) === 0 ? false : true
      }

    getEnchantment(enchantment) {
        if (!this.hasComponent('minecraft:enchantments')) return;
        if (!this.hasEnchantment(enchantment)) return;
        const component = this._IItem.getComponent('minecraft:enchantments')
    
        return component.enchantments.getEnchantment(MinecraftEnchantmentTypes[enchantment])
      }  
}


/**
 * This function allows to get all the necessary data of an item (nameTag, lore, id, data, amount, and its enchantments in a way that can be used later)
 * @param {item} - The itemStack you want to get its data.
 * @returns {Object}
*/
export function getItemData(item) {
  const itemData = {
    id: item.id,
    data: item.data,
    amount: item.amount,
    nameTag: item.nameTag,
    lore: item.getLore(),
    enchantments: [],
  }
  if (!item.hasComponent("enchantments")) return itemData
  const enchants = item.getComponent('enchantments')?.enchantments;
      if (enchants) {
    for (let k in MinecraftEnchantmentTypes) {
      const type = MinecraftEnchantmentTypes[k];
      if (!enchants.hasEnchantment(type)) continue;
      const enchant = enchants.getEnchantment(type);
      itemData.enchantments.push({
        id: enchant.type.id,
        level: enchant.level,
      });
    }
  }
  return itemData;
}

/**
 * This function allows you to create a new itemStack instance with the data saved with the getItemData function.
 * @param {itemData} - The data saved to create a new item
 * @returns {itemStack}
*/
export function newItem(itemData) {
  const item = new ItemStack(
    Items.get(itemData.id),
    itemData.amount,
    itemData.data
  );
  item.nameTag = itemData.nameTag;
  item.setLore(itemData.lore);
  const enchComp = item.getComponent("enchantments");
  const enchants = enchComp?.enchantments;
  if (enchants) {
    for (let enchant of itemData.enchantments) {
      const key = enchant.id
        .replace("minecraft:", "")
        .replace(/_(.)/g, (match) => match[1].toUpperCase());
      const type = MinecraftEnchantmentTypes[key];
      if (!type) continue;
      enchants.addEnchantment(new Enchantment(type, enchant.level));
    }
    enchComp.enchantments = enchants;
  }
  return item;
}