export function genUUID() {
    let chars = 'abcdefghijknmlopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ123456789'
    let result = ''
    let length = chars.length
    for (let i=0; i<23; i++) {
      result += chars.charAt(Math.floor(Math.random() *length))
    }
    return result
}