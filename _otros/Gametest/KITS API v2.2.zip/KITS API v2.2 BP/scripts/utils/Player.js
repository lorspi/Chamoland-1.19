import { world, Player as _IPlayer, BlockLocation, ItemStack, Dimension, PlayerInventoryComponentContainer, Location, Effect, MinecraftEffectTypes } from 'mojang-minecraft'

export class Player {

  constructor(player) {
      this._IPlayer = player
      this.dimension = world.getDimension('overworld')
    }
    /**
     * Get _IPlayer object
     * @returns {_IPlayer}
     */
  getIPlayer() {
      return this._IPlayer
  }
  /**
   * Get an array with all player tags
   * @returns {Array}
   */
  getTags() {
    return this._IPlayer.getTags()
  }
  /**
   * Get player nameTag
   * @returns {string}
   */
  getNameTag() {
      return this._IPlayer.nameTag
  }
  /**
   * Get player name (gamerTag)
   * @returns {string}
   */
  getName() {
      return this._IPlayer.name
  }
  /**
   * Check if the player has a tag
   * @param {String} tag you want to search
   * @returns {boolean}
   */
  hasTag(tag) {
    return this._IPlayer.hasTag(tag)
  }
  /**
   * Check if the player has all the tags
   * @param {Array} Array of tags you want to check
   * @returns {boolean}
   */
  hasAllTags(tags) {
    return tags.every(tag => this.hasTag(tag))
  }
  
  exists(name) {
    return [...world.getPlayers()].some(player => player.nameTag == name || player.name == name)
  }
  /**
   * Get player score
   * @param {String} objective you want to get the score for
   * @returns 
   */
  getScore(objective, useZero = true) {
    try {
      const obj = world.scoreboard.getObjective(objective)
      return obj.getScore(this._IPlayer.scoreboard)
    } catch {
      return useZero ? 0 : NaN
    }
  }
  /**
   * Remove a tag from a player
   * @param {String} tag you want to remove
   * @returns 
   */
  removeTag(tag) {
    return this._IPlayer.removeTag(tag)
  }
  
  /**
   * Get player dimension object
   * @returns {Dimension}
   */
  getDimension() {
    return this._IPlayer.dimension
  }
  
  /**
   * Get player dimension name
   * @returns {string}
  */
  getDimensionName() {
    const id = this.getDimension().id.split(':')[1].replace(/_/g, ' ')

    return id
  }
  /**
   * Get player selected slot
   * @returns {Number}
   */
  getSelectedSlot() {
    return this._IPlayer.selectedSlot
  }
  /**
   * Get player inventory component
   * @returns {PlayerInventoryComponentContainer}
   */
  getInventory() {
      return this._IPlayer.getComponent('minecraft:inventory')
  }
  /**
   * Get player position
   * @returns {Location}
   */
  getPos() {
    const pos = this._IPlayer.location
    return {
    x: pos.x,
    y: pos.y,
    z: pos.z
    }
  }
  /**
   * Get player head position
   * @returns {Location}
   */
  getHeadLocation() {
      const pos = this._IPlayer.headLocation
      return {
          x: pos.x,
          y: pos.y,
          z: pos.z
      }
  }
  
  getViewVector() {
      return this._IPlayer.viewVector
  }
  
  /**
   * Kick player from server
   * @param Reason 
   * Why you kick the player
   */
  kick(reason = 'undefined') {
      this.dimension.runCommand(`kick "${this.getName()}" ${reason}`)
  }
  /**
   * Set a nameTag to the player
   * @param {String} nameTag that you want to put on the player
   */
  setNameTag(nametag) {
      this._IPlayer.nameTag = nametag
  }
  /**
   * Add a tag to the player
   * @param {String} tag you want to add
   */
  addTag(tag) {
      this._IPlayer.addTag(tag)
  }
  /**
   * Get player current health
   * @returns {EntityHealthComponent}
   */
  getHealth() {
      return this._IPlayer.getComponent('minecraft:health')
  }
  /**
   * Get item from player inventory
   * @param {Number} slot from which you want to get the item
   * @returns {ItemStack}
   */
  getItem(slot) {
      return this.getInventory().container.getItem(slot)
  }
  /**
   * Get player effect
   * @param {Effect} effect you want to get
   */
  getEffect(effect) {
      this._IPlayer.getEffect(effect)
  }
  /**
   * Add effect to the player
   * @param {Effect} effect you want to add
   * @param {Number} duration of the effect
   * @param {Number} amplifier level of the effect
   */
  addEffect(effect, duration, amplifier) {
      this._IPlayer.addEffect(effect, duration, amplifier)
  }
  /**
   * Execute an event in the player
   * @param {String} event you want to trigger
   */
  triggerEvent(event) {
      this._IPlayer.triggerEvent(event)
  }
  /**
   * 
   * @param {String} component you want to get
   * @returns {null}
   */
  getComponent(component) {
      return this._IPlayer.getComponent(component)
  }
  /**
   * 
   * @param {String} command you want to execute
   * @param debug
   * @returns {Object}
   */
  executeCommand(cmd, debug = false) {
    try {
      const command = this._IPlayer.runCommand(cmd)

      return {
        statusMessage: command.statusMessage,
        data: command,
        err: false,
      }
    } catch (error) {
        if (debug) console.warn(`[KITS-API] [Player#executeCommand]: ${String(error)}`)

      return {
        statusMessage: String(error),
        data: null,
        err: true,
      }
    }
  }
    /**
     * 
     * @param {String} objective to which you want to set the amount
     * @param amount
     * @returns {Number}
     */
  setScore(objective, amount) {
      this.executeCommand(`scoreboard players set @s "${objective}" ${amount}`)
      return this.getScore(objective)
  }
  /**
   * 
   * @param objective to which you want to add the score
   * @param amount 
   * @returns {Number}
   */
  addScore(objective, amount) {
      this.executeCommand(`scoreboard players add @s "${objective}" ${amount}`)
      return this.getScore(objective)
  }
  
  removeScore(objective, amount) {
      this.executeCommand(`scoreboard players remove @s "${objective}" ${amount}`)
      return this.getScore(objective)
  }
  
  setGamemode(gamemode) {
      if (gamemode === this.getGamemode()) return;
      const command = this.executeCommand(`gamemode ${gamemode}`)
      if (command.err) return console.error("setGamemode Error: " + command.statusMessage)
  }
  
  getGamemode() {
      try {
    const gmc = this.executeCommand(`testfor @s[name="${this.getName()}", m=c]`)
    const gma = this.executeCommand(`testfor @s[name="${this.getName()}", m=a]`)
    const gms = this.executeCommand(`testfor @s[name="${this.getName()}", m=s]`)
    if (!gmc.err) return 'creative'
    if (!gma.err) return 'adventure'
    if (!gms.err) return 'survival'

    return 'unknown'
    } catch {}
  }
  
  openForm() {
      if (this.getGamemode() == 'creative') {
      this.setGamemode('survival')
      this.dimension.runCommand(`damage "${this.getName()}" 0 entity_attack`)
      this.setGamemode('creative')
      } else {
          this.dimension.runCommand(`damage "${this.getName()}" 0 entity_attack`)
      }
  }
  
  vanish() {
      this.triggerEvent('vanish')
      this.addEffect(MinecraftEffectTypes.invisibility, 99999999, 1)
      this.addEffect(MinecraftEffectTypes.nightVision, 99999999, 1)
      this.addEffect(MinecraftEffectTypes.speed, 99999999, 1)
      this.addEffect(MinecraftEffectTypes.jumpBoost, 99999999, 1)
      this.addEffect(MinecraftEffectTypes.fireResistance, 99999999, 255)
      this.executeCommand('ability @s mayfly true')
      this.addTag('isVanish')
  }
  
  unvanish() {
      this.triggerEvent('unvanish')
      if (this.getGamemode() === "survival" | "adventure") this.executeCommand('ability @s mayfly false')
      else {
      this.executeCommand(`effect @s clear`)
      this.removeTag('isVanish')
    }
  }
  
  sendMessage(message) {
      this.executeCommand(`tellraw @s {"rawtext":[{"text":"${message}"}]}`)
  }
  
  hasGuiOpen() {
      return this.hasTag('guiOpen')
  }

  kill() {
    this._IPlayer.kill()
  }
  
  isSneaking() {
      return this._IPlayer.isSneaking
  }
  
  isSwimming() {
      return this.hasTag('isSwimming')
  }
  
  isSprinting() {
      return this.hasTag('isSprinting')
  }
  
  isSleeping() {
      return this.hasTag('isSleeping')
  }
  
  isRiding() {
      return this.hasTag('isRiding')
  }
  
  isMoving() {
      return this.hasTag('isMoving')
  }
  
  isOnGround() {
      return this.hasTag('isOnGround')
  }
  
  isJumping() {
      return this.hasTag('isJumping')
  }
  
  isInWater() {
      return this.hasTag('isInWater')
  }
  
  isInFire() {
      return this.hasTag('isInFire')
  }
  
  isAlive() {
      return this.hasTag('isAlive')
  }
  
  isGliding() {
    return this.hasTag('isGliding')
  }
  
  isEating() {
    return this.hasTag('isEating')
  }
  
  isFirstPerson() {
    return this.hasTag('isFirstPerson')
  }
  
  isInvisible() {
    return this.hasTag('isInvisible')
  }
  
  itemIsCharged() {
    return this.hasTag('itemIsCharged')
  }
  
  isUsingItem() {
    return this.hasTag('isUsingItem')
  }
  
  isSelectedItem() {
    return this.hasTag('isSelectedItem')
  }
}