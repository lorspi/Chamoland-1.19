import CommandHandler from '../classes/CommandRegistration.js'
import CommandBuilder from '../classes/builders/CommandBuilder.js'
import { Player } from '../utils/Player.js'
import Chat from '../utils/Chat.js'
import { world, Location } from "mojang-minecraft"

const registration = new CommandBuilder()
.setName('test')
.setDescription("test")
.setUsage(['ts'])
.setCancelMessage(true)

CommandHandler.register(registration, (response) => {
    let tags = response.player.getTags().filter((tag) => tag.startsWith('kitCooldown:'))
    for (let tag of tags) {
        response.player.removeTag(tag)
    }
})

