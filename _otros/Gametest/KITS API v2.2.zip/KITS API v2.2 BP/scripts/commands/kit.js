/*
Developers:
Aex66: 
Discord: Aex66#0202
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
           _____                 
          /  _  \   ____ ___  ___
         /  /_\  \_/ __ \\  \/  /
        /    |    \  ___/ >    < 
        \____|__  /\___  >__/\_ \
                \/     \/      \/
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
© Copyright 2022 all rights reserved. Do NOT steal, copy the code, or claim it as yours.

Thank you
*/

import { setTickTimeout } from '../utils/scheduling.js'
import CommandBuilder from "../classes/builders/CommandBuilder.js";
import CommandHandler from "../classes/CommandRegistration.js"
import { KitForm } from '../formUI/Forms/KitForm.js'
import { KitFormMember } from '../formUI/Forms/KitFormMember.js'
import { KitReclaimSelect } from '../formUI/Forms/KitReclaimSelect.js'
import { Player } from '../utils/Player.js'

const registration = new CommandBuilder()
	.setName('kit')
	.setDescription('Open kit form UI')
	.setUsage(['kit'])
	.setCancelMessage(true)
CommandHandler.register(registration, (response) => {
    const Plr = new Player(response.player)
    switch(!!Plr.hasTag("staff")) {
        case true:
         Plr.openForm()
         setTickTimeout(() => KitForm(response.player), 10)
         break;
         case false:
          Plr.openForm()
          setTickTimeout(() => KitFormMember(response.player), 10)
         break;
    }
})