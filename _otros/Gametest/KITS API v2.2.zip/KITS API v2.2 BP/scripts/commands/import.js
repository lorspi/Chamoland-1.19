import "./kit.js"
import "./help.js"
import "./prefix.js"
import "./test.js"