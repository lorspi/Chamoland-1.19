The files in this folder must be generated with the build script in the root directory (build.py).
